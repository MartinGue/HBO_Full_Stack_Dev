'use strict'

document.getElementById('myInput').addEventListener('change', AddNumbers)

function AddNumbers (e) {
    console.log(Number(e.target.value) + 3);
    let myVar = 'test';
    let myNumber = 42;
mynumber ++;

}
